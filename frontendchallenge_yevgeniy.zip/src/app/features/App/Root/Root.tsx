import React from 'react';
import { normal as NormalForm } from "../../CoreUI/Form/Form.stories";
import './Root.scss';

const Root: React.FC = () => (
  <NormalForm />
);

export default Root;
