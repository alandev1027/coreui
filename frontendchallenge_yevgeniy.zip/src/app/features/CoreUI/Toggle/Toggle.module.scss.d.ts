export const toggleButton: string;
export const checked: string;
export const disabled: string;
export const toggleHandle: string;
export const input: string;
