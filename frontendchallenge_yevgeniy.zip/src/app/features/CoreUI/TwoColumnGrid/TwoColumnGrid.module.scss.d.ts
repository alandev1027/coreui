export const twoColumnContainer: string;
export const normal: string;
export const big: string;
