export const container: string;
export const label: string;
export const right: string;
export const disabled: string;
