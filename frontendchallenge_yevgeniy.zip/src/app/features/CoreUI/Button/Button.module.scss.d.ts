export const button: string;
export const inverse: string;
export const big: string;
export const normal: string;
export const small: string;
export const fullWidth: string;
export const loading: string;
export const spinner: string;
