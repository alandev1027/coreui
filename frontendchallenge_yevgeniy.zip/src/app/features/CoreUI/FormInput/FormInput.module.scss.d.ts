export const label: string;
export const fillWidth: string;
export const errorLabel: string;
