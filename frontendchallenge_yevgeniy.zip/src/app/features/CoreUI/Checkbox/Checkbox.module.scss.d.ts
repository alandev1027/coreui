export const checkbox: string;
export const disabled: string;
export const checked: string;
export const input: string;
