export const input: string;
export const fillWidth: string;
export const error: string;
