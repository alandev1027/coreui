interface Props {
  isHovered?: boolean;
}

type HoverIcon = React.FC<Props>;

export default HoverIcon;
